You can place scripts for animations in this folder.
